<?php

namespace App\Http\Controllers;

use App\Activity;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class LoginController extends Controller
{
    public function login(){
        if(Auth::attempt(\request()->only(['email','password']))){
            Activity::activity('User login');
            return redirect()->intended('home');
        }
        return back()->withInput()->with(['error' => true]);
    }
}
