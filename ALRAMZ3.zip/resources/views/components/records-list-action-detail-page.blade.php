<a href="{{ route('detail',$record->id) }}" class="btn btn-xs btn-info"><i class="fas fa fa-fw fa-share-square"></i> Details</a>
