<button class="btn btn-xs btn-info" onclick="RecordListDetail({{ $record->id }})">Details</button>
