@extends('layout')

@section('title','Pending Records')

@section('back-button',true)

@section('content')
    @php
        $head = \cache()->get('head'); $bStatus = $head['Status - Broker']; $cStatus = $head['Status - Compliance'];
        $records = \App\Record::whereNull($cStatus)->where($bStatus,'Submitted')->latest(); $search = "%" .(request()->search_text). "%";
        if(request()->search_text) $records->where(function($Q)use($search){ for($i = 1; $i <= 5; $i++) $Q->orWhere('index' . $i,'like',$search); });
        $records = $records->paginate(config('alramz.record_view_count.admin'));
        $links = $records->withQueryString()->links();
    @endphp
    <div class="modal fade" tabindex="-1" role="dialog" id="viewModal">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" data-record="{{ $head[config('alramz.record_detail_view_title.admin')] }}"></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <div class="row py-2">
                        @foreach($head as $display => $field)
                            <div class="col-4 py-1"><strong>{{ $display }}</strong></div>
                            <div class="col-1 py-1">:</div>
                            <div class="col-7 py-1" data-record="{{ $field }}"></div>
                        @endforeach
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row mb-2">
        <div class="col-4">@component('search') @endcomponent</div>
        <div class="ml-auto">{!! $links !!}</div>
    </div>
    <div class="table-responsive">
        <table class="table table-sm">
            <thead><tr>@foreach(config('alramz.record_view_heads.admin') as $th)<th> {{ $th }} </th>@endforeach <th>&nbsp;</th></tr></thead>
            <tbody>
                @forelse($records as $record)
                    <tr>
                        @foreach(config('alramz.record_view_heads.admin') as $td) <td>{{ $record->{ $head[$td] } }}</td> @endforeach
                        <td>
                            <button class="btn btn-xs btn-info" onclick="ViewDetail({{ $record->id }})">Details</button>
                            <a href="{{ route('detail',$record->id) }}" class="btn btn-xs btn-info"><i class="fas fa fa-fw fa-share-square"></i> Details</a>
                        </td>
                    </tr>
                @empty
                    <tr><td colspan="{{ count(config('alramz.record_view_heads.admin')) }}">No records</td><td>&nbsp;</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
@stop

@push('js')
    <script type="text/javascript">
        @php  @endphp
        let records = @json(collect($records->items())->keyBy->id);
        function ViewDetail(id) {
            let record = records[id];
            $.each(record,function(field,data){ $('[data-record="'+field+'"]').text(data); })
            $('#viewModal').modal('show')
        }
    </script>
@endpush
