@extends('layout')

@section('title','Approved Records')

@section('back-button',true)

@section('content')
    @php
        $head = cache()->get('head'); $bStatus = $head['Status - Broker']; $cStatus = $head['Status - Compliance'];
        $records = \App\Record::latest()->where($cStatus,'Approved'); $search = "%" .(request()->search_text). "%";
        if(request()->search_text) $records->where(function($Q)use($search){ for($i = 1; $i <= 5; $i++) $Q->orWhere('index' . $i,'like',$search); });
        $records = $records->paginate(config('alramz.record_view_count.compliance'));
        $links = $records->withQueryString()->links();
    @endphp
    <div class="modal fade" tabindex="-1" role="dialog" id="viewModal">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" data-record="{{ $head[config('alramz.record_detail_view_title.compliance')] }}"></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <div class="row py-2">
                        @foreach($head as $display => $field)
                            <div class="col-4 py-1"><strong>{{ $display }}</strong></div>
                            <div class="col-1 py-1">:</div>
                            <div class="col-7 py-1" data-record="{{ $field }}"></div>
                        @endforeach
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" tabindex="-1" role="dialog" id="submitModal">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" data-record="{{ $head[config('alramz.record_detail_view_title.compliance')] }}"></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <form method="post" action="{{ route('compliance.view') }}" name="submit-form">@csrf
                        <input type="hidden" name="action" value="submit">
                        <input type="hidden" name="id" value="">
                        <input type="hidden" name="status" value="">
                        <textarea class="form-control" name="note"></textarea>
                    </form>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-primary float-right" onclick="doSubmit()">Submit</button>
                </div>
            </div>
        </div>
    </div>

    @if(session()->has('success')) <div class="alert alert-success"> Record Status Updated Accordingly !</div> @endif

    <div class="row mb-2">
        <div class="col-4">@component('search') @endcomponent</div>
        <div class="ml-auto">{!! $links !!}</div>
    </div>
    <div class="table-responsive">
        <table class="table table-sm">
            @php $headings = array_merge(config('alramz.record_view_heads.compliance')) @endphp
            <thead><tr>@foreach($headings as $th)<th> {{ $th }} </th>@endforeach <th>&nbsp;</th></tr></thead>
            <tbody>
                @forelse($records as $record)
                    <tr>
                        @foreach($headings as $td) <td>{{ $record->{ $head[$td] } }}</td> @endforeach
                        <td>
                            <button class="btn btn-xs btn-info" onclick="ViewDetail({{ $record->id }})">Details</button>
                            <a href="{{ route('detail',$record->id) }}" class="btn btn-xs btn-info"><i class="fas fa fa-fw fa-share-square"></i> Details</a>
                            {{--@unless($record->{ $head['Status - Compliance'] })
                                <button class="btn btn-xs btn-info" onclick="Approve({{ $record->id }})">Approve</button>
                                <button class="btn btn-xs btn-danger" onclick="Reject({{ $record->id }})">Reject</button>
                                <button class="btn btn-xs btn-warning" onclick="Incomplete({{ $record->id }})">Incomplete</button>
                            @endunless--}}
                        </td>
                    </tr>
                @empty
                    <tr><td colspan="{{ count(config('alramz.record_view_heads.compliance')) }}">No records</td><td>&nbsp;</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
@stop

@push('js')
    <script type="text/javascript">
        let records = @json(collect($records->items())->keyBy->id);
        function ViewDetail(id) {
            let record = records[id];
            $.each(record,function(field,data){ $('[data-record="'+field+'"]').text(data); })
            $('#viewModal').modal('show')
        }
        function Approve(id) { ShowModal('Approved',id,'Approve comments if any!!'); }
        function Reject(id) { ShowModal('Rejected',id,'Reject comments if any!!'); }
        function Incomplete(id) { ShowModal('Incomplete',id,'Comments if any!!'); }
        function ShowModal(status,id,placeholder) {
            let titleDiv = $('.modal-title','#submitModal'), title = records[id][titleDiv.attr('data-record')]; titleDiv.text(title);
            $('[name="id"]','#submitModal').val(id);
            $('[name="status"]','#submitModal').val(status);
            $('[name="note"]','#submitModal').attr({ placeholder });
            $('#submitModal').modal('show')
        }
        function doSubmit() {
            $('form[name="submit-form"]').submit();
        }
    </script>
@endpush
