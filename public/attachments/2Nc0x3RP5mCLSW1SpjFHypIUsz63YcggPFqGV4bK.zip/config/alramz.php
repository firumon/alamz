<?php

    return [

        'activity_recent_day'   =>  7,
        'activity_recent_date_format'   =>  'h:i a - D d/m',
        'activity_recent_count'   =>  25,

        'record_view_heads'     =>  [
            'admin'     =>  ['Account Name','Order Id','Quantity','Price'],
            'broker'     =>  ['Account Name','Order Id','Quantity','Price'],
            'compliance'     =>  ['Account Name','Order Id','Quantity','Price'],
        ],
        'record_view_count'     =>  [
            'admin'     =>  15,
            'broker'     =>  15,
            'compliance'     =>  15,
        ],
        'record_detail_view_title'     =>  [
            'admin'     =>  'Order Id',
            'broker'     =>  'Order Id',
            'compliance'     =>  'Order Id',
        ],
        'detail_view_ignore'     =>  [
            'admin'     =>  [],
            'broker'     =>  [],
            'compliance'     =>  [],
        ],
        'detail_view_title'     =>  [
            'admin'     =>  'Order Id',
            'broker'     =>  'Account Name',
            'compliance'     =>  'Order Id',
        ],
    ];
