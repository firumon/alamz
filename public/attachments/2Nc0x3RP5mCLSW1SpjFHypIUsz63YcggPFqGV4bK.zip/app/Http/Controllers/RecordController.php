<?php

namespace App\Http\Controllers;

use App\Activity;
use App\Record;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class RecordController extends Controller
{
    public function Broker(){
        if(request()->getMethod() === 'POST'){
            $request = request()->all(); $record = Record::find($request['id']);
            if($record){
                $head = cache()->get('head'); $type = $request['item'];
                $status = $type === 'pending' ? 'Pending' : 'Submitted';
                $attachment = ($type === 'mail' && request()->hasFile('mail-data')) ? \request()->file('mail-data')->store('/','attachment') : null;
                $note = $type === 'mail' ? null : $request[$type . '-data'];
                foreach ([$head['Submit Type'] => $type,$head['Status - Broker'] => $status,$head['Attachment'] => $attachment, $head['Note - Broker'] => $note] as $key => $value)
                    $record->$key = $value;
                if($status === 'Submitted') $record->{ $head['Status - Compliance'] } = null;
                $record->save(); self::activity('Broker',$record->id,$status);
                return redirect()->back()->with(['success' => true]);
            }

        }
        return view('broker.view');
    }
    public function Compliance(){
        if(request()->getMethod() === 'POST'){
            $request = request()->all(); $record = Record::find($request['id']);
            if($record){
                $head = cache()->get('head');
                $status = $request['status']; $note = $request['note'];
                foreach ([$head['Status - Compliance'] => $status, $head['Note - Compliance'] => $note, $head['Compliance'] => Auth::user()->name] as $key => $value)
                    $record->$key = $value;
                if($status === 'Incomplete') $record->{ $head['Status - Broker'] } = null;
                $record->save(); self::activity('Compliance',$record->id,$status);
                return redirect()->back()->with(['success' => true]);
            }

        }
        return view('compliance.view');
    }

    private static function activity($person,$id,$status){
        Activity::activity("$person changed status of <a href='" . route('detail',[$id]) . "'>Record " . $id . "</a> into $status");
    }
}
